#include"myPoint.h"

int main()
{
	myPoint point1;
	myPoint point2(10, 30.5);

	point1.pointDistance(point2);

	// myPoint point3 = myPoint(22.0, 35.0);
	
	return 0;
}