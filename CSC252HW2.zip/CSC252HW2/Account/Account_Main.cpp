#include"Account.h"
using CSC252HW1::Account;

void do_work();

int main()
{
	// function to create 10 account object
	do_work();

	return 0;
}
